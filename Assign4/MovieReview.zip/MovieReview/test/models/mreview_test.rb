require 'test_helper'

class MreviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
