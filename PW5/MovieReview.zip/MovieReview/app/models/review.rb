class Review < ActiveRecord::Base
 validates :movietitle, presence: true
 validates :rating, presence: true
end
